package modul4.tugas.util;

public interface iMenu {
    void menu();
}
